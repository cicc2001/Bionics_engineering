#include <yarp/os/all.h>
#include <iostream>

using namespace yarp::os;


int main(int argc, char *argv[]) {

    // Set up YARP
    Network yarp;

    // Create port
    Port p;
    bool ok  = p.open("/examples/port/sender");
    if (!ok) {
        std::cerr << "Failed to open port" << std::endl;
        return 1;
    }

    // waiting for the receiver before transmitting
    yarp.waitConnection("/examples/port/sender", "/examples/port/receiver");

    // send data in a loop
    

        // prepare the message using a bottle
        Bottle b;
        b.addString("Hello");
       
        // send the message through the port
        std::cout << "Sending Hello message " << std::endl;
        p.write(b);

    

    // close port
    p.close();

    return 0;


}
